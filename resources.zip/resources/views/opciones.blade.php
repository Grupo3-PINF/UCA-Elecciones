<?php $titulo = "opciones"; ?>
@extends('layouts/layout')
@section('content')
<div id="opciones">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<p>
					Esta es la pagina de las opciones.
				</p>
                <p>
                    <td>{{$opciones}}</td>
                </p>	
			</div>
		</div>
	</div>
</div>

@stop