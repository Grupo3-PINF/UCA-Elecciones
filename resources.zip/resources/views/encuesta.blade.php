<?php $titulo = "Crear votacion"; ?>
@extends('layouts/layout')
@section('content')
<div id="crearvotacion">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<h3>LOREM IPSUM</h3>
				<p>Parrafo to grande y guapo de prueba pa ver xdxd Parrafo to grande y guapo de prueba pa ver xdxd Parrafo to grande y guapo de prueba pa ver xdxd Parrafo to grande y guapo de prueba pa ver xdxd Parrafo to grande y guapo de prueba pa ver xdxd Parrafo to grande y guapo de prueba pa ver xdxd Parrafo to grande y guapo de prueba pa ver xdxd</p>
			</div>
			<div class="col-xs-12 col-4">
				<div class="votacion">
					<h4>Preguntas</h4>
					<i class="far fa-question-circle"></i>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent vitae congue sem, eu dignissim urna.</p>
				</div>
			</div>
			<div class="col-xs-12 col-4">
				<div class="votacion">
					<h4>Encuesta</h4>
					<i class="far fa-envelope"></i>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent vitae congue sem, eu dignissim urna.</p>
				</div>
			</div>
			<div class="col-xs-12 col-4">
				<div class="votacion">
					<h4>Desarrollo</h4>
					<i class="far fa-file-code"></i>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent vitae congue sem, eu dignissim urna.</p>
				</div>
			</div>
		</div>
	</div>
</div>
@stop